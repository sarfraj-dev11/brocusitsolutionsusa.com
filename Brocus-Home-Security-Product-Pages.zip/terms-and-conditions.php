<?php
$page_title = 'Terms and Conditions | Brocus IT Solutions LLC';
$page_desc  = 'The Terms and Conditions governing your use of brocusitsolutionsusa.com and the advisory and referral services provided by Brocus IT Solutions LLC.';
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/head.php';
?>
<?php include 'includes/header.php'; ?>

<!-- HERO BANNER -->
<section class="page-hero" style="background:radial-gradient(ellipse 80% 80% at 50% 40%, #5746c6 0%, #5746c6 45%, #110c28 100%);">
  <div class="page-hero-inner">
    <span class="label">Legal</span>
    <h1 class="page-h">Terms and Conditions</h1>
    <p class="page-sub">The terms governing your use of brocusitsolutionsusa.com and the services provided by Brocus IT Solutions LLC.</p>
  </div>
</section>

<!-- CONTENT -->
<section style="background:linear-gradient(160deg, #fdfcff 0%, #f5f0ff 50%, #eff6ff 100%);position:relative;overflow:hidden;">
  <div style="position:absolute;top:-120px;right:-120px;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,#f0ebff 0%,transparent 70%);pointer-events:none;"></div>
  <div style="position:absolute;bottom:-80px;left:-80px;width:360px;height:360px;border-radius:50%;background:radial-gradient(circle,#ebf5ff 0%,transparent 70%);pointer-events:none;"></div>

<style>
    .legal-wrap {
        max-width: 1150px;
        margin: 0 auto;
        padding: 5rem 1.5rem 7rem;
        position: relative;
        z-index: 1;
    }

    .legal-meta {
        font-size: .82rem;
        color: #94A3B8;
        margin-bottom: 3rem;
        border-bottom: 1px solid rgba(15,23,42,.08);
        padding-bottom: 1.5rem
    }

    .legal-wrap h2 {
        font-weight: 700;
        margin: 2.5rem 0 .75rem;
        color: #0F172A
    }

    .legal-wrap p,
    .legal-wrap li {
        font-size: .92rem;
        color: #475569;
        line-height: 1.85;
        margin-bottom: .75rem
    }

    .legal-wrap ul {
        padding-left: 1.25rem;
        margin-bottom: .75rem
    }

    .legal-wrap a {
        color: #6D28D9
    }

    .legal-wrap address {
        font-style: normal;
        color: #374151;
        line-height: 1.8;
        font-size: .9rem;
        margin-top: .5rem
    }
</style>
<div class="legal-wrap">
    <p class="legal-meta">Last updated: June 11, 2025</p>

    <p>These Terms and Conditions ("Terms") govern your access to and use of brocusitsolutionsusa.com (the "Site") and the services offered by Brocus IT Solutions LLC ("Brocus," "we," "us," or "our"). By using the Site or submitting a request, you agree to these Terms. If you do not agree, please do not use the Site.</p>

    <h2>1. Who we are and what we do</h2>
    <p>Brocus is an independent advisory and referral service. We help you understand your options and connect you with independent third-party providers who supply, install, and service the products and services you choose. We do not manufacture, sell, install, monitor, or service those products ourselves, and we are not the provider of the end services you may ultimately purchase.</p>

    <h2>2. Our role and the role of providers</h2>
    <p>Any provider we refer you to is an independent business, not an agent, partner, or employee of Brocus. The agreement for any product or service is solely between you and that provider. We do not control and are not responsible for the pricing, availability, quality, timing, installation, or performance of any provider's products or services. You are responsible for reviewing and agreeing to the provider's own terms before purchasing.</p>

    <h2>3. Compensation disclosure</h2>
    <p>Brocus may receive compensation from third-party providers in connection with referrals made through the Site. This compensation does not increase the price you pay and does not obligate you to purchase anything.</p>

    <h2>4. Eligibility</h2>
    <p>You must be at least 18 years old and located in the United States to use the Site and submit a request. By using the Site, you represent that you meet these requirements and that the information you provide is accurate and belongs to you.</p>

    <h2>5. Consent to be contacted</h2>
    <p>When you submit a request, you authorize Brocus and the providers we work with to contact you using the phone number and email address you provide, including by automated telephone dialing system, prerecorded or artificial voice messages, and text messages, for marketing and service purposes. Consent is not a condition of any purchase. You may opt out as described in our Privacy Policy and our Electronic Disclosure Consent.</p>

    <h2>6. Acceptable use</h2>
    <p>You agree not to use the Site to submit false or fraudulent information, to violate any law, to infringe the rights of others, to introduce harmful code, or to attempt to gain unauthorized access to our systems. We may suspend or terminate access for any misuse.</p>

    <h2>7. Intellectual property</h2>
    <p>The Site and its content, including text, graphics, logos, and design, are owned by or licensed to Brocus and are protected by intellectual property laws. You may not copy, reproduce, distribute, or create derivative works from our content without our written permission.</p>

    <h2>8. No professional advice and no guarantee</h2>
    <p>The information on the Site and the guidance we provide are for general informational purposes and are not legal, financial, or professional advice. We make no guarantee that any provider will meet your expectations or that any product or service will achieve a particular result.</p>

    <h2>9. Disclaimer of warranties</h2>
    <p>The Site and our services are provided "as is" and "as available," without warranties of any kind, whether express or implied, including warranties of merchantability, fitness for a particular purpose, and non-infringement. We do not warrant that the Site will be uninterrupted, error free, or secure.</p>

    <h2>10. Limitation of liability</h2>
    <p>To the fullest extent permitted by law, Brocus and its owners, officers, employees, and affiliates will not be liable for any indirect, incidental, special, consequential, or punitive damages, or for any loss arising from your use of the Site or from any product, service, or conduct of a third-party provider. Where liability cannot be excluded, our total liability will not exceed one hundred US dollars (100 USD).</p>

    <h2>11. Indemnification</h2>
    <p>You agree to indemnify and hold harmless Brocus and its owners, officers, employees, and affiliates from any claims, damages, losses, and expenses, including reasonable attorney fees, arising out of your use of the Site, your violation of these Terms, or your dealings with any third-party provider.</p>

    <h2>12. Third-party links</h2>
    <p>The Site may contain links to third-party websites. We do not control and are not responsible for their content, products, or practices. Accessing them is at your own risk.</p>

    <h2>13. Governing law and venue</h2>
    <p>These Terms are governed by the laws of the State of Florida, without regard to its conflict of laws rules. You agree that any dispute not subject to arbitration will be brought exclusively in the state or federal courts located in Hillsborough County, Florida, and you consent to their jurisdiction.</p>

    <h2>14. Dispute resolution and arbitration</h2>
    <p>Any dispute arising out of or relating to these Terms or the Site will be resolved by binding arbitration on an individual basis, administered under the rules of a recognized arbitration body, and not as part of any class or representative action. You and Brocus waive the right to a jury trial and the right to participate in a class action, to the extent permitted by law. You may opt out of this arbitration provision by sending written notice to us within 30 days of first accepting these Terms.</p>

    <h2>15. Changes to these Terms</h2>
    <p>We may update these Terms at any time. The "Last updated" date reflects the latest revision, and your continued use of the Site means you accept the updated Terms.</p>

    <h2>16. Severability and entire agreement</h2>
    <p>If any provision of these Terms is found unenforceable, the remaining provisions will remain in effect. These Terms, together with our Privacy Policy and Electronic Disclosure Consent, are the entire agreement between you and Brocus regarding the Site.</p>

    <h2>17. Contact us</h2>
    <address>Brocus IT Solutions LLC<br>10639 Mistflower Lane, Tampa, FL 33647<br>Email: <a href="mailto:support@brocusitsolutionsusa.com">support@brocusitsolutionsusa.com</a><br>Phone: <a href="tel:<?= PHONE_TEL ?>"><?= PHONE_DISPLAY ?></a></address>
</div>
</section>
<?php include 'includes/footer.php'; ?>